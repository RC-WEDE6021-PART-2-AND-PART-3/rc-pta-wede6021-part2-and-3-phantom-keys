<?php
session_start();
if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    if ($id > 0 && isset($_SESSION['cart'][$id])) {
        unset($_SESSION['cart'][$id]);
        $_SESSION['cart_message'] = 'Item removed from cart.';
    }
}
header('Location: cart.php');
exit();
?>
