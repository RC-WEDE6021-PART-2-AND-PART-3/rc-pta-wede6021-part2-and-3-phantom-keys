<?php
session_start();
include 'DBConn.php';
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: adminlogin.php?redirect=admin_products.php');
    exit();
}

$res = $conn->query('SELECT * FROM products ORDER BY created_at DESC');
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Admin - Products</title>
  <link rel="stylesheet" href="css/style.css">
  </head>
<body>
<div class="container">
    <h2>Products (Admin)</h2>
    <p><a href="admin_add_product.php">+ Add Product</a> | <a href="purchase_history.php">View Purchase History</a></p>
    <table class="admin-table">
        <thead>
            <tr><th>ID</th><th>Name</th><th>Price</th><th>Brand</th><th>Category</th><th>Created</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php while ($row = $res->fetch_assoc()): ?>
            <tr>
                <td><?= $row['product_id'] ?></td>
                <td><?= htmlspecialchars($row['product_name']) ?></td>
                <td>R<?= number_format($row['price'],2) ?></td>
                <td><?= htmlspecialchars($row['brand']) ?></td>
                <td><?= htmlspecialchars($row['category']) ?></td>
                <td><?= $row['created_at'] ?></td>
                <td class="admin-actions">
                    <a href="edit_product.php?id=<?= $row['product_id'] ?>">Edit</a>
                    <a href="delete_product.php?id=<?= $row['product_id'] ?>" onclick="return confirm('Delete this product?')">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>
