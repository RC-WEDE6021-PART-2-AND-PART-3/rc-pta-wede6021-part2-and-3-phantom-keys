<?php
session_start();
include 'DBConn.php';

 $ref = $_GET['ref'] ?? '';
 $order_id = isset($_GET['order']) ? (int)$_GET['order'] : 0;

 // fetch meta if available
 $meta = [];
 if ($order_id) {
   $stmt = $conn->prepare('SELECT meta_key, meta_value FROM order_meta WHERE order_id = ?');
   $stmt->bind_param('i', $order_id);
   $stmt->execute();
   $res = $stmt->get_result();
   while ($r = $res->fetch_assoc()) {
     $meta[$r['meta_key']] = $r['meta_value'];
   }
   $stmt->close();
 }

?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Order Success</title>
  <link rel="stylesheet" href="css/style.css">
  </head>
<body>
<div class="container">
    <h2>Thank you — Order placed</h2>
    <p>Your reference number: <strong><?= htmlspecialchars($ref) ?></strong></p>
    <p>Order ID: <?= $order_id ?></p>
    <?php if (!empty($meta)): ?>
      <h4>Delivery</h4>
      <p><strong>Phone:</strong> <?= htmlspecialchars($meta['phone'] ?? '') ?></p>
      <p><strong>Address:</strong><br><?= nl2br(htmlspecialchars($meta['address'] ?? '')) ?></p>
    <?php endif; ?>
    <p><a href="index.php">Continue Shopping</a> | <a href="orders.php">View Orders</a></p>
</div>
</body>
</html>
