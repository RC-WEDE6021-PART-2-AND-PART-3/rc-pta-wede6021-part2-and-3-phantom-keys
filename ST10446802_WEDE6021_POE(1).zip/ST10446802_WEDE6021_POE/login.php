<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include "DBConn.php";

$message = "";
$active_form = "login"; // track which form to show
$sticky_username = "";
$sticky_email = "";
$sticky_name = "";

// If already logged in, show details instead of form
if (isset($_SESSION["user_id"])) {
    $logged_in = true;
} else {
    $logged_in = false;
}

// REGISTER USER
if (isset($_POST["register"])) {
    $active_form = "register";
    $name = trim($_POST["name"]?? '');
    $email = trim($_POST["email"]?? '');
    $username = trim($_POST["username"]?? '');
    $password = $_POST["password"]?? '';
    $role = $_POST["role"]?? 'buyer';

    // Keep sticky values
    $sticky_name = $name;
    $sticky_email = $email;
    $sticky_username = $username;

    if (empty($name) || empty($email) || empty($username) || empty($password)) {
        $message = "All fields are required";
    } elseif (strlen($password) < 8) {
        $message = "Password must be at least 8 characters";
    } else {
        // Check if username or email exists
        $stmt = $conn->prepare("SELECT user_id FROM users WHERE username =? OR email =?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $message = "Username or email already exists";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $is_approved = 0; // New users need admin approval

            $stmt2 = $conn->prepare("INSERT INTO users (name, username, email, password, role, is_approved) VALUES (?,?,?,?,?,?)");
            $stmt2->bind_param("sssssi", $name, $username, $email, $hashedPassword, $role, $is_approved);

            if ($stmt2->execute()) {
                $message = "Registered successfully. Wait for admin approval before login.";
                $active_form = "login"; // Switch back to login
                $sticky_name = $sticky_email = $sticky_username = ""; // Clear sticky
            } else {
                $message = "Error: ". $stmt2->error;
            }
            $stmt2->close();
        }
        $stmt->close();
    }
}

// LOGIN USER
if (isset($_POST["login"])) {
    $active_form = "login";
    $username = trim($_POST["username"]?? '');
    $password = $_POST["password"]?? '';

    // Sticky username only
    $sticky_username = $username;

    if ($username === '' || $password === '') {
        $message = "Username and password required";
    } else {
        $stmt = $conn->prepare("SELECT user_id, name, username, email, password, role, is_approved FROM users WHERE username =?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();

            if (password_verify($password, $user["password"])) {
                // Check approval first
                if ($user["is_approved"] == 0) {
                    $message = "Your account is not approved yet. Contact admin.";
                } else {
                    // Success - set session
                    $_SESSION["user_id"] = $user["user_id"];
                    $_SESSION["username"] = $user["username"];
                    $_SESSION["name"] = $user["name"];
                    $_SESSION["email"] = $user["email"];
                    $_SESSION["role"] = $user["role"];

                    $redirect = isset($_POST["redirect"]) ? $_POST["redirect"] : "index.php";
                    header("Location: " . $redirect);
                    exit();
                }
            } else {
                $message = "Wrong password";
            }
        } else {
            $message = "User not found";
        }
        $stmt->close();
    }
}

// LOGOUT
if (isset($_GET["logout"])) {
    session_destroy();
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login | PASTTIMES</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/login.css">
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
</head>
<body>
<div class="auth-container">
<div class="wrapper">

   
        <!-- REGISTER FORM -->
        <form method="POST" class="glass-box" <?= $active_form === 'register'? '' : 'style="display:none;"'?>>
            <h2>Register</h2>
            <?php if ($message && $active_form === 'register'):?>
                <div class="error-msg"><?= htmlspecialchars($message)?></div>
            <?php endif;?>
            <input type="text" name="name" placeholder="Full Name" value="<?= htmlspecialchars($sticky_name)?>" required minlength="2">
            <input type="text" name="username" placeholder="Username" value="<?= htmlspecialchars($sticky_username)?>" required minlength="4">
            <input type="email" name="email" placeholder="Email" value="<?= htmlspecialchars($sticky_email)?>" required>
            <input type="password" name="password" placeholder="Password - min 8 chars" required minlength="8">
            <button type="submit" name="register">Register</button>
            <p style="text-align:center; margin-top:10px;">Have account? <a href="#" onclick="showLogin();return false;">Login</a></p>
        </form>

        <!-- LOGIN FORM -->
        <form method="POST" class="glass-box" <?= $active_form === 'login'? '' : 'style="display:none;"'?>>
            <h2>Login</h2>
            <?php if ($message && $active_form === 'login'):?>
                <div class="error-msg"><?= htmlspecialchars($message)?></div>
            <?php endif;?>
            <input type="text" name="username" placeholder="Username" value="<?= htmlspecialchars($sticky_username)?>" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="hidden" name="redirect" value="<?= htmlspecialchars($_GET['redirect']?? 'index.php')?>">
            <button type="submit" name="login">LOGIN</button>
            <p style="text-align:center; margin-top:10px;">No account? <a href="#" onclick="showRegister();return false;">Register</a></p>
            <p style="text-align:center;"><a href="adminlogin.php">LOGIN AS ADMIN</a></p>
        </form>

   
</div>
</div>

<script>
function showRegister() {
    document.querySelectorAll('.glass-box').forEach(f => f.style.display = 'none');
    document.querySelectorAll('.glass-box')[0].style.display = 'block';
}
function showLogin() {
    document.querySelectorAll('.glass-box').forEach(f => f.style.display = 'none');
    document.querySelectorAll('.glass-box')[1].style.display = 'block';
}
</script>

</body>
</html>