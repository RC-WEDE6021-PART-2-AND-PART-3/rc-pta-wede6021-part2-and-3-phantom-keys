<?php
session_start();
include 'DBConn.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) {
    header('Location: cart.php');
    exit();
}

$total = 0.0;
foreach ($cart as $id => $qty) {
    $stmt = $conn->prepare('SELECT product_id, price FROM products WHERE product_id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $p = $res->fetch_assoc();
    $stmt->close();
    if (!$p) continue;
    $total += $p['price'] * $qty;
}

// Create reference id
$reference = strtoupper(substr(md5(uniqid((string)$user_id, true)), 0, 10));
// Insert into orders table (buyer_id, total_amount)
$stmt = $conn->prepare('INSERT INTO orders (buyer_id, total_amount, payment_status, delivery_status) VALUES (?, ?, "paid", "processing")');
$stmt->bind_param('id', $user_id, $total);
$stmt->execute();
$order_id = $stmt->insert_id;
$stmt->close();

// Server-side: capture address/phone/notes from POST and basic validation
$phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';
$address = isset($_POST['address']) ? trim($_POST['address']) : '';
$notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';
if (strlen($phone) < 7 || strlen($address) < 5) {
    // invalid input
    header('Location: checkout.php');
    exit();
}

// Ensure order_meta table exists for storing address/phone/reference
// create without an explicit foreign key to avoid FK creation issues on some setups
$conn->query("CREATE TABLE IF NOT EXISTS order_meta (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    meta_key VARCHAR(100) NOT NULL,
    meta_value TEXT,
    INDEX (order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

// store meta
$metas = [ 'reference' => $reference, 'phone' => $phone, 'address' => $address, 'notes' => $notes ];
foreach ($metas as $k => $v) {
    $stmtm = $conn->prepare('INSERT INTO order_meta (order_id, meta_key, meta_value) VALUES (?, ?, ?)');
    $stmtm->bind_param('iss', $order_id, $k, $v);
    $stmtm->execute();
    $stmtm->close();
}

// Insert order items
foreach ($cart as $id => $qty) {
    $stmt = $conn->prepare('SELECT product_id, price FROM products WHERE product_id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $p = $res->fetch_assoc();
    $stmt->close();
    if (!$p) continue;

    $stmt2 = $conn->prepare('INSERT INTO order_item (order_id, product_id, quantity, price_at_purchase) VALUES (?, ?, ?, ?)');
    $stmt2->bind_param('iiid', $order_id, $id, $qty, $p['price']);
    $stmt2->execute();
    $stmt2->close();

    // If products table has a `stock` column, decrement it (safe check)
    $hasStock = false;
    $check = $conn->query("SHOW COLUMNS FROM products LIKE 'stock'");
    if ($check && $check->num_rows > 0) {
        $hasStock = true;
    }
    if ($hasStock) {
        $stmt3 = $conn->prepare('UPDATE products SET stock = GREATEST(stock - ?, 0) WHERE product_id = ?');
        $stmt3->bind_param('ii', $qty, $id);
        $stmt3->execute();
        $stmt3->close();
    }
}

// Clear cart
unset($_SESSION['cart']);

// Redirect to a confirmation page (show reference)
header('Location: order_success.php?ref=' . urlencode($reference) . '&order=' . $order_id);
exit();
?>