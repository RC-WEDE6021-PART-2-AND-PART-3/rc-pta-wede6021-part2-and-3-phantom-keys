<?php
session_start();
include "DBConn.php";
$isLoggedIn = isset($_SESSION["user_id"]);
$role = $_SESSION["role"] ?? 'guest';
$username = $_SESSION["username"] ?? 'User';
$cartCount = 0;
if (isset($_SESSION["cart"]) && is_array($_SESSION["cart"])) {
    $cartCount = array_sum($_SESSION["cart"]);}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Home - PASTTIMES</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/home.css">
  <link rel="icon" type="image/x-icon" href="images/logo.jpg">
</head>
<body>
<!-- SVG Filter for Glass Distortion -->
<svg style="display: none">
  <filter id="glass-distortion">
    <feTurbulence type="turbulence" baseFrequency="0.008" numOctaves="2" result="noise" />
    <feDisplacementMap in="SourceGraphic" in2="noise" scale="77" />
  </filter>
</svg>

<nav class="navbar">
    <div class="nav-left">
        <img src="images/logo.jpg" alt="logo">
    </div>
    <div class="nav-links">
        <a href="index.php">Home</a>
        <a href="product.php">Products</a>
        <a href="cart.php">Cart (<?= $cartCount ?? 0 ?>)</a>
        <a href="about-us.php">About</a>
    </div>

    <div class="glass-icon dropdown">
        <button onclick="menu.hidden^=1" class="dropdown-toggle" aria-label="Menu">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="22" height="22">
                <path fill-rule="evenodd" d="M11.828 2.25c-.916 0-1.699.663-1.85 1.567l-.091.549a.798.798 0 0 1-.517.608 7.45 7.45 0 0 0-.478.198.798.798 0 0 1-.796-.064l-.453-.324a1.875 1.875 0 0 0-2.416.2l-.243.243a1.875 1.875 0 0 0-.2 2.416l.324.453a.798.798 0 0 1 .064.796 7.448 7.448 0 0 0-.198.478.798.798 0 0 1-.608.517l-.55.092a1.875 1.875 0 0 0-1.566 1.849v.344c0 .916.663 1.699 1.567 1.85l.549.091c.281.047.508.25.608.517.06.162.127.321.198.478a.798.798 0 0 1-.064.796l-.324.453a1.875 1.875 0 0 0 .2 2.416l.243.243c.648.648 1.67.733 2.416.2l.453-.324a.798.798 0 0 1 .796-.064c.157.071.316.137.478.198.267.1.47.327.517.608l.092.55c.15.903.932 1.566 1.849 1.566h.344c.916 0 1.699-.663 1.85-1.567l.091-.549a.798.798 0 0 1 .517-.608 7.52 7.52 0 0 0 .478-.198.798.798 0 0 1 .796.064l.453.324a1.875 1.875 0 0 0 2.416-.2l.243-.243c.648-.648.733-1.67.2-2.416l-.324-.453a.798.798 0 0 1-.064-.796c.071-.157.137-.316.198-.478.1-.267.327-.47.608-.517l.55-.091a1.875 1.875 0 0 0 1.566-1.85v-.344c0-.916-.663-1.699-1.567-1.85l-.549-.091a.798.798 0 0 1-.608-.517 7.507 7.507 0 0 0-.198-.478.798.798 0 0 1 .064-.796l.324-.453a1.875 1.875 0 0 0-.2-2.416l-.243-.243a1.875 1.875 0 0 0-2.416-.2l-.453.324a.798.798 0 0 1-.796.064 7.462 7.462 0 0 0-.478-.198.798.798 0 0 1-.517-.608l-.091-.55a1.875 1.875 0 0 0-1.85-1.566h-.344ZM12 15.75a3.75 3.75 0 1 0 0-7.5 3.75 3.75 0 0 0 0 7.5Z" clip-rule="evenodd" />
            </svg>
        </button>

        <ul id="menu" hidden class="dropdown-menu">
            <?php if ($isLoggedIn): ?>
                <li class="menu-header" color="white">Hi, <?= htmlspecialchars($username) ?></li>
                
                <?php if ($role === 'admin'): ?>
                    <!-- ADMIN MENU -->
                    <li><a href="profile.php">Profile</a></li>
                    <li class="submenu">
                        <span>Database ▸</span>
                        <ul>
                            <li><a href="admin_users.php">View Users</a></li>
                            <li><a href="admin_edit_user.php">Edit Users</a></li>
                            <li><a href="approveuser.php">Approve Registrations</a></li>
                            <li><a href="approve_requests.php">Approve User Requests</a></li>
                        </ul>
                    </li>
                    <li><a href="admin_products.php">Edit Products</a></li>
                    <li><a href="settings.php">Settings</a></li>
                    <li><a href="login.php?logout=1">Logout</a></li>
                
                <?php else: ?>
                    <!-- USER/BUYER/SELLER MENU -->
                    <li><a href="profile.php">Profile</a></li>
                    <li><a href="cart.php">Cart</a></li>
                    <li><a href="orders.php">Order History</a></li>
                    <li><a href="settings.php">Settings</a></li>
                <?php endif; ?>

                <hr>
                <li><a href="login.php?logout=1">Logout</a></li>
            
            <?php else: ?>
                <!-- GUEST MENU -->
                <li><a href="login.php">Login</a></li>
                <li><a href="login.php#register">Register</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>


<header>
    <h1>PASTTIMES</h1>
</header>

<div class="top-bar">
    <div>
        <?php if ($isLoggedIn): ?>
            Welcome, <?= $username ?>
        <?php else: ?>
            Welcome, Guest
        <?php endif; ?>
    </div>
    <div>
        <?php if (!$isLoggedIn): ?>
            <a href="login.php">Login</a> / <a href="login.php">Register</a>
        <?php else: ?>
            <a href="view_cart.php">Cart (<?= $cartCount ?>)</a>
        <?php endif; ?>
    </div>
</div>

<main>
    <section class="intro">
        <h2>Style Meets Creativity</h2>
        <p>Look good with the t-shirt brand designed for your style and creativity.</p>
    </section>

    <section class="content">
        <div class="left">
            <p>
                We provide a platform where artists can showcase their creativity 
                by branding their designs on high-quality t-shirts.
            </p>
        </div>

        <div class="right">
            <img src="images/7.jpg" alt="shirt">
            <p>Explore our latest designs and samples.</p>
        </div>
    </section>
</main>

<footer>
    <p>&copy; 2024 PASTTIMES</p>
</footer>
<script>

document.addEventListener('click', e => {
    if (!e.target.closest('.dropdown')) {
        document.getElementById('menu').hidden = true;
    }
});
</script>
</body>
</html>