<?php
session_start();
include 'DBConn.php';
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: adminlogin.php?redirect=purchase_history.php');
    exit();
}

// Fetch orders with totals
$orders = $conn->query('SELECT o.order_id, o.buyer_id, o.order_date, o.total_amount, u.name as buyer_name FROM orders o LEFT JOIN users u ON o.buyer_id = u.user_id ORDER BY o.order_date DESC');

// Aggregate total revenue
$revRes = $conn->query('SELECT SUM(total_amount) as total_revenue, COUNT(order_id) as total_orders FROM orders');
$rev = $revRes->fetch_assoc();

?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Purchase History</title>
  <link rel="stylesheet" href="css/style.css">
  </head>
<body>
<div class="container">
    <h2>Purchase History</h2>
    <p class="muted">Total Orders: <?= $rev['total_orders'] ?? 0 ?> — Revenue: R<?= number_format($rev['total_revenue'] ?? 0,2) ?></p>

    <table class="admin-table">
        <thead><tr><th>Order ID</th><th>Buyer</th><th>Date</th><th>Total</th><th>Items</th></tr></thead>
        <tbody>
        <?php while ($o = $orders->fetch_assoc()): ?>
            <tr>
                <td><?= $o['order_id'] ?></td>
                <td><?= htmlspecialchars($o['buyer_name'] ?: 'Guest') ?></td>
                <td><?= $o['order_date'] ?></td>
                <td>R<?= number_format($o['total_amount'],2) ?></td>
                <td>
                    <?php
                    $stmt = $conn->prepare('SELECT oi.quantity, oi.price_at_purchase, p.product_name FROM order_item oi LEFT JOIN products p ON oi.product_id = p.product_id WHERE oi.order_id = ?');
                    $stmt->bind_param('i', $o['order_id']);
                    $stmt->execute();
                    $res = $stmt->get_result();
                    while ($it = $res->fetch_assoc()) {
                        echo htmlspecialchars($it['product_name']) . ' x' . $it['quantity'] . ' (R' . number_format($it['price_at_purchase'],2) . ')<br>';
                    }
                    $stmt->close();
                    ?>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>
