<?php
session_start();
include 'DBConn.php';
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: adminlogin.php?redirect=edit_product.php');
    exit();
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) { header('Location: admin_products.php'); exit(); }

$stmt = $conn->prepare('SELECT * FROM products WHERE product_id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
$product = $res->fetch_assoc();
$stmt->close();

if (!$product) { header('Location: admin_products.php'); exit(); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['product_name'] ?? '';
    $desc = $_POST['description'] ?? '';
    $price = (float)($_POST['price'] ?? 0);
    $size = $_POST['size'] ?? '';
    $brand = $_POST['brand'] ?? '';
    $condition = $_POST['product_condition'] ?? 'new';
    $category = $_POST['category'] ?? 'men';

    $image = $product['image'];
    if (!empty($_FILES['image']['name'])) {
        $image = time() . '_' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], 'images/' . $image);
    }

    $stmt = $conn->prepare('UPDATE products SET product_name=?, description=?, price=?, size=?, brand=?, product_condition=?, category=?, image=? WHERE product_id=?');
    $stmt->bind_param('ssdsssssi', $name, $desc, $price, $size, $brand, $condition, $category, $image, $id);
    $stmt->execute();
    $stmt->close();
    header('Location: admin_products.php');
    exit();
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Edit Product</title>
  <link rel="stylesheet" href="css/style.css">
  </head>
<body>
<div class="container">
    <h2>Edit Product #<?= $product['product_id'] ?></h2>
    <form method="POST" enctype="multipart/form-data">
        <label>Product Name</label>
        <input name="product_name" required value="<?= htmlspecialchars($product['product_name']) ?>">
        <label>Description</label>
        <textarea name="description"><?= htmlspecialchars($product['description']) ?></textarea>
        <label>Price</label>
        <input name="price" type="number" step="0.01" required value="<?= htmlspecialchars($product['price']) ?>">
        <label>Size</label>
        <input name="size" value="<?= htmlspecialchars($product['size']) ?>">
        <label>Brand</label>
        <input name="brand" value="<?= htmlspecialchars($product['brand']) ?>">
        <label>Condition</label>
        <select name="product_condition"><option value="new">new</option><option value="like_new">like_new</option><option value="good">good</option><option value="fair">fair</option></select>
        <label>Category</label>
        <select name="category"><option value="men">men</option><option value="women">women</option><option value="accessories">accessories</option><option value="shoes">shoes</option></select>
        <label>Image (leave blank to keep)</label>
        <input type="file" name="image">
        <button type="submit">Save</button>
    </form>
</div>
</body>
</html>
