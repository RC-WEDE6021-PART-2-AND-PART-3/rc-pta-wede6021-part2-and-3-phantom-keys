<?php
session_start();
include 'DBConn.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) {
    header('Location: cart.php');
    exit();
}

$total = 0;
foreach ($cart as $id => $qty) {
    $stmt = $conn->prepare('SELECT product_id, product_name, price FROM products WHERE product_id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $p = $res->fetch_assoc();
    $stmt->close();
    if (!$p) continue;
    $total += $p['price'] * $qty;
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Checkout - PASTTIMES</title>
  <link rel="stylesheet" href="css/style.css">
  </head>
<body>
<div class="container">
    <h2>Checkout</h2>
    <p>Total: R<?= number_format($total,2) ?></p>

    <form method="POST" action="placeorder.php" id="checkoutForm">
        <label>Phone number</label>
        <input type="text" name="phone" id="phone" pattern="[0-9+\- ]{7,30}" required placeholder="e.g. 0821234567">

        <label>Delivery Address</label>
        <textarea name="address" id="address" required minlength="10" placeholder="Street, Suburb, City"></textarea>

        <label>Notes (optional)</label>
        <input type="text" name="notes">
        <button type="submit">Place Order</button>
    </form>

    <script>
    document.getElementById('checkoutForm').addEventListener('submit', function(e){
        var phone = document.getElementById('phone').value.trim();
        var addr = document.getElementById('address').value.trim();
        if (phone.length < 7 || addr.length < 10) {
            alert('Please enter a valid phone number and delivery address.');
            e.preventDefault();
        }
    });
    </script>
</div>
</body>
</html>
