<?php
session_start();
include "DBConn.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$stmt = $conn->prepare("SELECT user_id, name, username, email, role, created_at, phone_number, address FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    die("User not found");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Profile - Clothing Store</title>
<link rel="stylesheet" href="css/style.css">
<style>
body {
    margin: 0;
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
}
</style>
</head>
<body>

<div class="profile-card">
    <div class="profile-header">
        <div class="avatar"><?= strtoupper(substr($user["name"], 0, 1)) ?></div>
        <h2><?= htmlspecialchars($user["name"]) ?></h2>
        <span class="role-badge"><?= htmlspecialchars($user["role"]) ?></span>
    </div>

    <div class="profile-body">
        <?php if (isset($_GET['updated']) && $_GET['updated'] == '1'): ?>
            <div class="alert">✓ Profile updated successfully</div>
        <?php endif; ?>

        <div id="view">
            <h3 class="section-title">Account Information</h3>
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">Username</div>
                    <div class="info-value"><?= htmlspecialchars($user["username"]) ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Email</div>
                    <div class="info-value"><?= htmlspecialchars($user["email"]) ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Phone</div>
                    <div class="info-value"><?= htmlspecialchars($user["phone_number"]) ?: 'Not set' ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Member Since</div>
                    <div class="info-value"><?= date('M d, Y', strtotime($user["created_at"])) ?></div>
                </div>
                <div class="info-item full">
                    <div class="info-label">Address</div>
                    <div class="info-value"><?= nl2br(htmlspecialchars($user["address"])) ?: 'Not set' ?></div>
                </div>
            </div>
            
            <div class="btn-group">
                <button class="btn" onclick="toggleEdit()">Edit Profile</button>
                <a href="index.php" class="btn secondary">Back to Store</a>
            </div>
        </div>

        <div id="edit" style="display:none;">
            <h3 class="section-title">Edit Information</h3>
            <form method="POST" action="update_profile.php">
                <label>Phone number</label>
                <input type="text" name="phone_number" value="<?= htmlspecialchars($user["phone_number"]) ?>" pattern="[0-9+\- ]*" maxlength="30">

                <label>Address</label>
                <textarea name="address" rows="3"><?= htmlspecialchars($user["address"]) ?></textarea>

                <div class="btn-group">
                    <button type="submit" class="btn">Save Changes</button>
                    <button type="button" class="btn secondary" onclick="toggleEdit()">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function toggleEdit() {
    let edit = document.getElementById("edit");
    let view = document.getElementById("view");
    edit.style.display = edit.style.display === "none" ? "block" : "none";
    view.style.display = view.style.display === "none" ? "block" : "none";
}
</script>

</body>
</html>