-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2026 at 08:47 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clothingstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `order_date` datetime DEFAULT current_timestamp(),
  `payment_status` enum('pending','paid','failed','refunded') DEFAULT 'pending',
  `delivery_status` enum('processing','shipped','delivered','cancelled') DEFAULT 'processing',
  `total_amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `buyer_id`, `order_date`, `payment_status`, `delivery_status`, `total_amount`) VALUES
(0, 0, '2026-06-18 17:43:30', 'paid', 'processing', 249.99),
(0, 0, '2026-06-18 17:47:20', 'paid', 'processing', 249.99),
(0, 0, '2026-06-18 17:51:36', 'paid', 'processing', 749.97),
(0, 0, '2026-06-18 17:52:35', 'paid', 'processing', 749.97);

-- --------------------------------------------------------

--
-- Table structure for table `order_item`
--

CREATE TABLE `order_item` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `price_at_purchase` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_item`
--

INSERT INTO `order_item` (`order_item_id`, `order_id`, `product_id`, `quantity`, `price_at_purchase`) VALUES
(0, 0, 7, 2, 249.99),
(0, 0, 6, 1, 249.99);

-- --------------------------------------------------------

--
-- Table structure for table `order_meta`
--

CREATE TABLE `order_meta` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `meta_key` varchar(100) NOT NULL,
  `meta_value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_meta`
--

INSERT INTO `order_meta` (`id`, `order_id`, `meta_key`, `meta_value`) VALUES
(1, 0, 'reference', 'BA0E443681'),
(2, 0, 'phone', '0729873492'),
(3, 0, 'address', 'pretrhgfdh'),
(4, 0, 'notes', '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `size` varchar(20) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `product_condition` enum('new','like_new','good','fair') NOT NULL DEFAULT 'new',
  `category` enum('men','women','accessories','shoes') NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `seller_id` int(11) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `description`, `price`, `size`, `brand`, `product_condition`, `category`, `image`, `seller_id`, `status`, `created_at`) VALUES
(1, 'PASTTIMES Tee Black', 'Classic PASTTIMES black t-shirt for men', 249.99, 'M', 'MEN', 'new', 'men', '1.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(2, 'PASTTIMES Tee White', 'Classic PASTTIMES white t-shirt for men', 249.99, 'L', 'MEN', 'new', 'men', '2.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(3, 'PASTTIMES Tee Blue', 'Classic PASTTIMES blue t-shirt for men', 249.99, 'XL', 'MEN', 'new', 'men', '3.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(4, 'PASTTIMES Tee Red', 'Classic PASTTIMES red t-shirt for men', 249.99, 'M', 'MEN', 'new', 'men', '4.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(5, 'PASTTIMES Tee Green', 'Classic PASTTIMES green t-shirt for men', 249.99, 'L', 'MEN', 'new', 'men', '5.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(6, 'PASTTIMES Tee Grey', 'Classic PASTTIMES grey t-shirt for men', 249.99, 'S', 'MEN', 'new', 'men', '6.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(7, 'PASTTIMES Tee Yellow', 'Classic PASTTIMES yellow t-shirt for men', 249.99, 'M', 'MEN', 'new', 'men', '7.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(8, 'PASTTIMES Tee Pink', 'PASTTIMES t-shirt for women - pink', 229.99, 'S', 'WOMEN', 'new', 'men', 'fruit1.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(9, 'PASTTIMES Tee Purple', 'PASTTIMES t-shirt for women - purple', 229.99, 'M', 'WOMEN', 'new', 'men', 'fruit4.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(10, 'PASTTIMES Tee Peach', 'PASTTIMES t-shirt for women - peach', 229.99, 'L', 'WOMEN', 'new', 'men', 'fruit5.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(11, 'PASTTIMES Tee Coral', 'PASTTIMES t-shirt for women - coral', 229.99, 'S', 'WOMEN', 'new', 'men', 'fruit6.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(12, 'PASTTIMES Tee Lavender', 'PASTTIMES t-shirt for women - lavender', 229.99, 'M', 'WOMEN', 'new', 'men', 'fruit7.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(13, 'PASTTIMES Tee Mint', 'PASTTIMES t-shirt for women - mint', 229.99, 'L', 'WOMEN', 'new', 'men', 'fruit9.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(14, 'PASTTIMES Tee Rose', 'PASTTIMES t-shirt for women - rose', 229.99, 'XS', 'WOMEN', 'new', 'men', 'fruit11.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(15, 'Vintage Anime Tee 1', 'Rare vintage anime print t-shirt', 399.99, 'M', 'VINTAGE', 'good', 'men', 'anime3.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(16, 'Vintage Anime Tee 2', 'Rare vintage anime print t-shirt', 399.99, 'L', 'VINTAGE', 'good', 'men', 'anime4.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(17, 'Vintage Anime Tee 3', 'Rare vintage anime print t-shirt', 399.99, 'S', 'VINTAGE', 'like_new', 'men', 'anime5.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(18, 'Vintage Anime Tee 4', 'Rare vintage anime print t-shirt', 399.99, 'M', 'VINTAGE', 'good', 'men', 'anime6.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(19, 'Vintage Anime Tee 5', 'Rare vintage anime print t-shirt', 399.99, 'XL', 'VINTAGE', 'fair', 'men', 'anime7.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(20, 'Vintage Anime Tee 6', 'Rare vintage anime print t-shirt', 399.99, 'L', 'VINTAGE', 'good', 'men', 'anime8.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(21, 'Vintage Anime Tee 7', 'Rare vintage anime print t-shirt', 399.99, 'M', 'VINTAGE', 'like_new', 'men', 'anime9.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(22, 'Vintage Anime Tee 8', 'Rare vintage anime print t-shirt', 399.99, 'S', 'VINTAGE', 'good', 'men', 'anime10.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(23, 'Vintage Anime Tee 9', 'Rare vintage anime print t-shirt', 399.99, 'L', 'VINTAGE', 'good', 'men', 'anime11.jpg', 2, 'pending', '2026-05-04 16:28:07'),
(24, 'Vintage Anime Tee 10', 'Rare vintage anime print t-shirt', 399.99, 'M', 'VINTAGE', 'fair', 'men', 'anime12.jpg', 2, 'pending', '2026-05-04 16:28:07');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `delivery_address` text DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('buyer','seller','admin') NOT NULL DEFAULT 'buyer',
  `is_approved` tinyint(1) NOT NULL DEFAULT 1,
  `is_verified_seller` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `username`, `email`, `phone_number`, `address`, `delivery_address`, `password`, `role`, `is_approved`, `is_verified_seller`, `created_at`) VALUES
(0, 'Admin User', 'admin', 'admin@mope.com', '0812345678', '123 Admin St, Pretoria', '123 Admin St, Pretoria', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 1, 0, '2026-06-17 13:04:32'),
(0, 'Thabo Seller', 'thabo_s', 'thabo@seller.com', '0812345678', '123 Admin St, Pretoria', '45 Market Ave, JHB', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'seller', 1, 1, '2026-06-17 13:04:32'),
(0, 'Nomsa Seller', 'nomsa_s', 'nomsa@seller.com', '0812345678', '123 Admin St, Pretoria', '12 Trade Rd, CPT', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'seller', 1, 1, '2026-06-17 13:04:32'),
(0, 'Mike Pending', 'mike_p', 'mike@seller.com', '0812345678', '123 Admin St, Pretoria', '89 Shop St, DBN', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'seller', 1, 0, '2026-06-17 13:04:32'),
(0, 'Lerato Buyer', 'lerato_b', 'lerato@buyer.com', '0812345678', '123 Admin St, Pretoria', '22 Home St, PTA', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'buyer', 1, 0, '2026-06-17 13:04:32'),
(0, 'Sipho Buyer', 'sipho_b', 'sipho@buyer.com', '0812345678', '123 Admin St, Pretoria', '77 Buy Ave, JHB', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'buyer', 1, 0, '2026-06-17 13:04:32'),
(0, 'jigsaw', 'saw', 'jigsaw@email.cam', '0812345678', '123 Admin St, Pretoria', NULL, '$2y$10$0bquumsZ2CXKD6f0dJKGHu4VI2mUmUGczbXvC3C..a1St3qXaDrF.', 'buyer', 1, 0, '2026-06-17 13:13:46'),
(0, 'theone', 'HimandHer', 'theone@gmail.com', '0812345678', '123 Admin St, Pretoria', NULL, '$2y$10$l6iBmDNDyr.dr/oHHPkXheiym.CxYCytN9cMhg40Wha0QRdgX.kSq', 'buyer', 0, 0, '2026-06-17 14:23:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `order_meta`
--
ALTER TABLE `order_meta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order_meta`
--
ALTER TABLE `order_meta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
