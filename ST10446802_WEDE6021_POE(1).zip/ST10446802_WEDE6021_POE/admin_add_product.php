<?php
session_start();
include 'DBConn.php';
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: adminlogin.php?redirect=admin_add_product.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['product_name'] ?? '';
    $desc = $_POST['description'] ?? '';
    $price = (float)($_POST['price'] ?? 0);
    $size = $_POST['size'] ?? '';
    $brand = $_POST['brand'] ?? '';
    $condition = $_POST['product_condition'] ?? 'new';
    $category = $_POST['category'] ?? 'men';

    $image = '';
    if (!empty($_FILES['image']['name'])) {
        $image = time() . '_' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], 'images/' . $image);
    }

    $stmt = $conn->prepare('INSERT INTO products (product_name, description, price, size, brand, product_condition, category, image, seller_id, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $status = 'pending';
    $seller = $_SESSION['user_id'];
    $stmt->bind_param('ssdsssssis', $name, $desc, $price, $size, $brand, $condition, $category, $image, $seller, $status);
    $ok = $stmt->execute();
    $stmt->close();
    if ($ok) header('Location: admin_products.php');
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Add Product</title>
  <link rel="stylesheet" href="css/style.css">
  </head>
<body>
<div class="container">
    <h2>Add Product</h2>
    <form method="POST" enctype="multipart/form-data">
        <label>Product Name</label>
        <input name="product_name" required>
        <label>Description</label>
        <textarea name="description"></textarea>
        <label>Price</label>
        <input name="price" type="number" step="0.01" required>
        <label>Size</label>
        <input name="size">
        <label>Brand</label>
        <input name="brand">
        <label>Condition</label>
        <select name="product_condition"><option value="new">new</option><option value="like_new">like_new</option><option value="good">good</option><option value="fair">fair</option></select>
        <label>Category</label>
        <select name="category"><option value="men">men</option><option value="women">women</option><option value="accessories">accessories</option><option value="shoes">shoes</option></select>
        <label>Image</label>
        <input type="file" name="image">
        <button type="submit">Create</button>
    </form>
</div>
</body>
</html>
