<?php
session_start();
include "DBConn.php";

$cart = $_SESSION["cart"] ?? [];
$total = 0;

foreach ($cart as $id => $qty) {
    $res = $conn->query("SELECT * FROM clothes WHERE id=$id");
    $p = $res->fetch_assoc();
    $total += $p["price"] * $qty;
}
?>

<h2>Checkout</h2>

<p>Total Amount: R<?php echo $total; ?></p>

<form method="POST" action="place_order.php">
    <input type="text" name="address" placeholder="Delivery Address" required>
    <button type="submit">Place Order</button>
</form>