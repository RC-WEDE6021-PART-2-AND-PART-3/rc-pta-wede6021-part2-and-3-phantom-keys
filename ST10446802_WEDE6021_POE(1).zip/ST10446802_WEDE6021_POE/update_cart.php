<?php
session_start();
// update quantity for a cart item
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id']) && isset($_POST['qty'])) {
    $id = (int)$_POST['id'];
    $qty = (int)$_POST['qty'];
    if ($id > 0) {
        if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) $_SESSION['cart'] = [];
        if ($qty > 0) {
            $_SESSION['cart'][$id] = $qty;
            $_SESSION['cart_message'] = 'Cart updated.';
        } else {
            unset($_SESSION['cart'][$id]);
            $_SESSION['cart_message'] = 'Item removed from cart.';
        }
    }
}
header('Location: cart.php');
exit();
?>
