<?php
session_start();
include "DBConn.php";

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Only allow updating phone_number and address
$phone = isset($_POST['phone_number']) ? trim($_POST['phone_number']) : '';
$address = isset($_POST['address']) ? trim($_POST['address']) : '';

// Basic validation/sanitization
if (strlen($phone) > 30) {
    $phone = substr($phone, 0, 30);
}

// Prepare update
$stmt = $conn->prepare("UPDATE users SET phone_number = ?, address = ? WHERE user_id = ?");
if (!$stmt) {
    header('Location: profile.php?updated=0');
    exit();
}

$stmt->bind_param('ssi', $phone, $address, $user_id);
$ok = $stmt->execute();
$stmt->close();

if ($ok) {
    header('Location: profile.php?updated=1');
} else {
    header('Location: profile.php?updated=0');
}
exit();

?>
