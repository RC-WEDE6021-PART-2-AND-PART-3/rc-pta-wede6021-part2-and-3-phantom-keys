<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 31);
include "DBConn.php";

$message = "";

// ADMIN LOGIN
if (isset($_POST["login"])) {
    $username = trim($_POST["username"]);
    $password = $_POST["password"];

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND role = 'admin'");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user["password"])) {
            $_SESSION["user_id"] = $user["user_id"];
            $_SESSION["username"] = $user["username"];
            $_SESSION["name"] = $user["name"];
            $_SESSION["role"] = $user["role"];
           

            $redirect = isset($_POST["redirect"]) ? $_POST["redirect"] : "index.php";
            header("Location: " . $redirect);
            exit();

           

        } 
        else {
           echo $message = "Wrong password";
        }
    } else {
        $message = "User not found";
    }
    $stmt->close();
}

// LOGOUT
if (isset($_GET["logout"])) {
    session_destroy();
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login | PASTTIMES</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/login.css">
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
</head>

<body>
    
<div class="auth-container">

    <!-- LOGIN -->
    <form method="POST" class="glass-box">
        <h2>ADMIN LOGIN</h2>
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="hidden" name="redirect" value="<?= htmlspecialchars($_GET['redirect'] ?? 'index.php') ?>">
        <button type="submit" name="login">Login</button>
        <a href="login.php">BACK TO USER LOGIN </a>
    </form>

</div>

<p style="text-align:center; color:red;">
    <?php echo $message; ?>
</p>

</body>
</html>