# PASTTIMES Clothing Store Website

## Overview
PASTTIMES is a PHP and MySQL based e-commerce website that allows users to browse clothing products, add items to a cart, place orders, and manage their profiles. The system also includes an administrative section for managing users, products, and account approvals.

---

## Features

### Customer Features
- User registration and login
- Account approval workflow
- Browse available products
- Add products to cart
- Update cart quantities
- Checkout and place orders
- View purchase history
- Manage user profile

### Administrator Features
- Administrator login
- Approve new user registrations
- View and manage users
- Add products
- Edit products
- Delete products
- Manage product listings

---

## System Requirements

### Software
- XAMPP, WAMP, or Laragon
- PHP 8.0 or later
- MySQL/MariaDB
- Modern web browser

---

## Installation Guide

### Step 1: Extract the Project
Extract the project folder into your web server directory.

Example:
- XAMPP: `htdocs/PASTTIMES`
- WAMP: `www/PASTTIMES`

### Step 2: Create the Database
1. Open phpMyAdmin.
2. Create a new database.
3. Import the file:

```
clothingstore.sql
```

### Step 3: Configure Database Connection
Open:

```
DBConn.php
```

Update the database credentials if required:

```php
$host = "localhost";
$username = "root";
$password = "";
$database = "clothingstore";
```

### Step 4: Start the Server
Start:
- Apache
- MySQL

### Step 5: Open the Website
Navigate to:

```
http://localhost/PASTTIMES/index.php
```

---

## Website Navigation

### Home Page
File:

```
index.php
```

Displays:
- Welcome page
- Navigation menu
- Featured content
- Cart indicator

### Products Page
File:

```
product.php
```

Allows users to:
- View available products
- Select products
- Add products to the shopping cart

### Cart
File:

```
cart.php
```

Users can:
- Review selected items
- Update quantities
- Remove items
- Proceed to checkout

### Checkout
File:

```
checkout.php
```

Used to:
- Confirm order details
- Complete purchases

### Purchase History
File:

```
purchase_history.php
```

Displays previous customer orders.

### Profile
File:

```
profile.php
```

Allows users to:
- View profile information
- Update personal details

---

## User Registration and Login

### Registering an Account
1. Open `login.php`.
2. Select **Register**.
3. Complete:
   - Full Name
   - Username
   - Email
   - Password
4. Submit registration.
5. Wait for administrator approval.

### Logging In
1. Open `login.php`.
2. Enter username and password.
3. Click **Login**.

---

## Administrator Guide

### Administrator Login
Open:

```
adminlogin.php
```

After successful login, administrators can:

### Product Management
- Add products (`admin_add_product.php`)
- View products (`admin_products.php`)
- Edit products (`edit_product.php`)
- Delete products (`delete_product.php`)

### User Management
- Approve registrations (`approveuser.php`)
- Manage user records

---

## Project Structure

```
PASTTIMES/
│
├── index.php
├── login.php
├── product.php
├── cart.php
├── checkout.php
├── profile.php
├── purchase_history.php
├── adminlogin.php
├── admin_products.php
├── admin_add_product.php
├── DBConn.php
├── clothingstore.sql
│
├── css/
├── js/
├── images/
│
└── README.md
```

---

## Security Features
- Password hashing using PHP password hashing functions
- Session-based authentication
- Input validation
- Account approval process for new users

---

## Troubleshooting

### Database Connection Error
Verify:
- MySQL is running
- Database name is correct
- Username and password in `DBConn.php` are correct

### Login Not Working
Verify:
- Account has been approved by an administrator
- Correct username and password are being used

### Images Not Displaying
Verify:
- The `images` folder is present
- Image paths have not been modified

---

## Authors
Developed as part of the WEDE6021 Portfolio of Evidence (POE) project.

Student Number: ST10446802

## Version
Version 1.0
