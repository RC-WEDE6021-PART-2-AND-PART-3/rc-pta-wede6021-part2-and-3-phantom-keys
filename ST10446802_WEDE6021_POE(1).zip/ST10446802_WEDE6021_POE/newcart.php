<?php
session_start();
include "dbConn.php";

if (isset($_POST["add_to_cart"]) && isset($_POST["product_id"])) {
    $product_id = (int)$_POST["product_id"];
    
    // Check if product exists
    $stmt = $conn->prepare("SELECT product_id FROM products WHERE product_id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        // Initialize cart if not set
        if (!isset($_SESSION["cart"])) {
            $_SESSION["cart"] = [];
        }
        
        // Add to cart or increment qty
        if (isset($_SESSION["cart"][$product_id])) {
            $_SESSION["cart"][$product_id]++;
        } else {
            $_SESSION["cart"][$product_id] = 1;
        }
        
        $_SESSION['cart_message'] = "Product added to cart!";
    } else {
        $_SESSION['cart_message'] = "Product not found.";
    }
    $stmt->close();
}

// Redirect back to products
header("Location: product.php");
exit();
?>