function register() {
    let username = document.getElementById("registerUsername").value;
    let password = document.getElementById("registerPassword").value;
    let confirm = document.getElementById("confirmPassword").value;

    if (password.length < 8) {
        document.getElementById("registerMessage").innerText = "Password must be at least 8 characters";
        return;
    }

    if (password !== confirm) {
        document.getElementById("registerMessage").innerText = "Passwords do not match";
        return;
    }

    document.getElementById("registerMessage").innerText = "Registered successfully (DB not connected yet)";
}

function login() {
    let username = document.getElementById("loginUsername").value;
    let password = document.getElementById("loginPassword").value;

    if (username === "" || password === "") {
        document.getElementById("loginMessage").innerText = "Fill all fields";
        return;
    }

    document.getElementById("loginMessage").innerText = "Login successful (DB not connected yet)";
}