<?php
session_start();
include "dbConn.php";

$isLoggedIn = isset($_SESSION["user_id"]);
$role = $_SESSION["role"] ?? 'guest';
$username = $_SESSION["username"] ?? 'User';
$cartCount = 0;
if (isset($_SESSION["cart"]) && is_array($_SESSION["cart"])) {
    $cartCount = array_sum($_SESSION["cart"]);}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>About Us - PASTTIMES</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/about-us.css">
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
</head>
<body>

<!-- NAVBAR -->
<svg style="display: none">
  <filter id="glass-distortion">
    <feTurbulence type="turbulence" baseFrequency="0.008" numOctaves="2" result="noise" />
    <feDisplacementMap in="SourceGraphic" in2="noise" scale="77" />
  </filter>
</svg>

<nav class="navbar">
    <div class="nav-left">
        <img src="images/logo.jpg" alt="logo">
    </div>
    <div class="nav-links">
        <a href="index.php">Home</a>
        <a href="product.php">Products</a>
        <a href="cart.php">Cart (<?= $cartCount ?? 0 ?>)</a>
        <a href="about-us.php">About</a>
    </div>

    <div class="glass-icon dropdown">
        <button onclick="menu.hidden^=1" class="dropdown-toggle" aria-label="Menu">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="22" height="22">
                <path fill-rule="evenodd" d="M11.828 2.25c-.916 0-1.699.663-1.85 1.567l-.091.549a.798.798 0 0 1-.517.608 7.45 7.45 0 0 0-.478.198.798.798 0 0 1-.796-.064l-.453-.324a1.875 1.875 0 0 0-2.416.2l-.243.243a1.875 1.875 0 0 0-.2 2.416l.324.453a.798.798 0 0 1 .064.796 7.448 7.448 0 0 0-.198.478.798.798 0 0 1-.608.517l-.55.092a1.875 1.875 0 0 0-1.566 1.849v.344c0 .916.663 1.699 1.567 1.85l.549.091c.281.047.508.25.608.517.06.162.127.321.198.478a.798.798 0 0 1-.064.796l-.324.453a1.875 1.875 0 0 0 .2 2.416l.243.243c.648.648 1.67.733 2.416.2l.453-.324a.798.798 0 0 1 .796-.064c.157.071.316.137.478.198.267.1.47.327.517.608l.092.55c.15.903.932 1.566 1.849 1.566h.344c.916 0 1.699-.663 1.85-1.567l.091-.549a.798.798 0 0 1 .517-.608 7.52 7.52 0 0 0 .478-.198.798.798 0 0 1 .796.064l.453.324a1.875 1.875 0 0 0 2.416-.2l.243-.243c.648-.648.733-1.67.2-2.416l-.324-.453a.798.798 0 0 1-.064-.796c.071-.157.137-.316.198-.478.1-.267.327-.47.608-.517l.55-.091a1.875 1.875 0 0 0 1.566-1.85v-.344c0-.916-.663-1.699-1.567-1.85l-.549-.091a.798.798 0 0 1-.608-.517 7.507 7.507 0 0 0-.198-.478.798.798 0 0 1 .064-.796l.324-.453a1.875 1.875 0 0 0-.2-2.416l-.243-.243a1.875 1.875 0 0 0-2.416-.2l-.453.324a.798.798 0 0 1-.796.064 7.462 7.462 0 0 0-.478-.198.798.798 0 0 1-.517-.608l-.091-.55a1.875 1.875 0 0 0-1.85-1.566h-.344ZM12 15.75a3.75 3.75 0 1 0 0-7.5 3.75 3.75 0 0 0 0 7.5Z" clip-rule="evenodd" />
            </svg>
        </button>

        <ul id="menu" hidden class="dropdown-menu">
            <?php if ($isLoggedIn): ?>
                <li class="menu-header" color="white">Hi, <?= htmlspecialchars($username) ?></li>
                
                <?php if ($role === 'admin'): ?>
                    <!-- ADMIN MENU -->
                    <li><a href="profile.php">Profile</a></li>
                    <li class="submenu">
                        <span>Database ▸</span>
                        <ul>
                            <li><a href="admin_users.php">View Users</a></li>
                            <li><a href="admin_edit_user.php">Edit Users</a></li>
                            <li><a href="approve_users.php">Approve Registrations</a></li>
                            <li><a href="approve_requests.php">Approve User Requests</a></li>
                        </ul>
                    </li>
                    <li><a href="admin_products.php">Edit Products</a></li>
                    <li><a href="settings.php">Settings</a></li>
                
                <?php else: ?>
                    <!-- USER/BUYER/SELLER MENU -->
                    <li><a href="profile.php">Profile</a></li>
                    <li><a href="cart.php">Cart</a></li>
                    <li><a href="orders.php">Order History</a></li>
                    <li><a href="settings.php">Settings</a></li>
                <?php endif; ?>

                <hr>
                <li><a href="login.php?logout=1">Logout</a></li>
            
            <?php else: ?>
                <!-- GUEST MENU -->
                <li><a href="login.php">Login</a></li>
                <li><a href="login.php#register">Register</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>

<header>
    <h1>PASTTIMES</h1>
</header>

<div class="top-bar">
    <div>
        <?php if ($isLoggedIn): ?>
            Welcome, <?= $username ?>
        <?php else: ?>
            Welcome, Guest
        <?php endif; ?>
    </div>
    <div>
        <?php if (!$isLoggedIn): ?>
            <a href="login.php">Login</a> / <a href="register.php">Register</a>
        <?php else: ?>
            <a href="viewcart.php">Cart (<?= $cartCount ?>)</a>
        <?php endif; ?>
    </div>
</div>

<main>
    <h2>About PASTTIMES</h2>
    
    <div class="row">
        <div class="left-side">
            <section>
                <p>
                    I decided to give my business a catchy name like MO&PE to catch the attention and curiosity of people.
                    In this business I sell T-shirts with my art or the customer's choice of art which they get a chance 
                    to be creative. I picked this business venture to exercise my creativity and grow my skills in doing
                    art and incorporating it in digital marketing.
                </p>
            </section>
        </div>
        
        <div class="right-side">
            <p>
                <strong>We are a branding NGO business that deals with screen printing for bulk orders with minimal colours
                and embroidery for those who like to feel and look vintage as well as heat transfer printing which 
                is best for a glossy feel and durable design.</strong>
            </p>
        </div>
    </div>

    <p>We print on t-shirts like the following to showcase our work and dedication:</p>
    <img src="images/7.jpg" alt="Sample t-shirt" style="width:200px; height:auto;">

    <h1>Contact Form</h1>
    <form id="contactForm" method="POST" action="contact_process.php">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>

        <label for="message">Message:</label><br>
        <textarea id="message" name="message" rows="4" required></textarea><br>

        <button type="submit">Submit</button>
    </form>

    <div id="result" style="margin-top: 20px;"></div>

    <h2>Contact Details</h2>
    <p>If you have any questions or inquiries, feel free to reach out to us:</p>
    <ul>
        <li>Email: <a href="mailto:mohaochiloane593@gmail.com">mohaochiloane593@gmail.com</a></li>
        <li>Phone: <a href="tel:+27729873492">+27 72 987 3492</a></li>
        <li>Address: 123 T-shirt Land, Art Town, AC 34221</li>
    </ul>

    <h3>Follow Us</h3>
    <ul>
        <li><a href="https://facebook.com" target="_blank">Facebook</a></li>
        <li><a href="https://twitter.com" target="_blank">Twitter</a></li>
        <li><a href="https://instagram.com" target="_blank">Instagram</a></li>
        <li><a href="https://wa.me/27729873492" target="_blank">WhatsApp</a></li>
    </ul>

    <h3>Our Location</h3>
    <div class="map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d28748.586602833166!2d28.35788627554273!3d-25.751620000880756!2m3!1f0!2f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e955ec51954f491%3A0xccd11d3953a014b7!2sSavannah%20Country%20Estate%2C%200081!5e0!3m2!1sen!2sza!4v1730750158384!5m2!1sen!2sza" 
        width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
</main>

<footer>
    <p>Clothes resales</p>
    <hr>
    <p>&copy; PASTTIMES</p>
    <p id="date-stamp"></p>
</footer>

<script src="js/script.js"></script>
</body>
</html>