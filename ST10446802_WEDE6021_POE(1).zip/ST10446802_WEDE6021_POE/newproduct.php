<?php
//add new product
session_start();
include "DBConn.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

if (isset($_POST["submit"])) {

    $name = $_POST["name"];
    $desc = $_POST["description"];
    $price = $_POST["price"];
    $seller_id = $_SESSION["user_id"];

    // IMAGE UPLOAD
    $image = $_FILES["image"]["name"];
    $target = "images/" . basename($image);

    move_uploaded_file($_FILES["image"]["tmp_name"], $target);

    $sql = "INSERT INTO products (name, description, price, image, seller_id)
            VALUES ('$name','$desc','$price','$image','$seller_id')";

    if ($conn->query($sql)) {
        echo "Product added!";
    } else {
        echo "Error";
    }
}

?>