<?php
session_start();
include "DBConn.php";

// Only admins can access
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== 'admin') {
    die("Access denied");
}

// Approve user
if (isset($_GET["approve"])) {
    $id = $_GET["approve"];
    $stmt = $conn->prepare("UPDATE users SET is_approved = 1 WHERE user_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: approve_users.php");
    exit();
}

// Show pending users
$result = $conn->query("SELECT user_id, name, username, email, role, created_at FROM users WHERE is_approved = 0");
?>

<h2>Pending User Approvals</h2>
<table border="1" cellpadding="10">
<tr><th>Name</th><th>Username</th><th>Email</th><th>Role</th><th>Action</th></tr>
<?php while($row = $result->fetch_assoc()): ?>
<tr>
    <td><?= $row['name'] ?></td>
    <td><?= $row['username'] ?></td>
    <td><?= $row['email'] ?></td>
    <td><?= $row['role'] ?></td>
    <td><a href="?approve=<?= $row['user_id'] ?>">Approve</a></td>
</tr>
<?php endwhile; ?>
</table>